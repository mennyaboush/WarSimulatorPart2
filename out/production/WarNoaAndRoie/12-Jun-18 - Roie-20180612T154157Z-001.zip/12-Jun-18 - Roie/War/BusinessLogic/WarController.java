package War.BusinessLogic;

import War.BusinessLogic.controllers.LauncherController;
import War.BusinessLogic.controllers.LauncherDestructorController;
import War.BusinessLogic.controllers.MissileController;
import War.BusinessLogic.controllers.MissileDestructorController;
import War.Entities.*;
import War.WarObserver.WarObservable;

import java.time.LocalTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.*;

import static java.time.temporal.ChronoUnit.SECONDS;


public class WarController extends WarObservable implements WarControllerFacade{ //Singleton
    private static WarController warController = new WarController();

    private static LocalTime startRunTime;
    private HashMap<Launcher, LauncherController> missileLaunchers;
    private HashMap<MissileDestructor, MissileDestructorController> missileDestructors;
    private HashMap<LauncherDestructor, LauncherDestructorController> launcherDestructors;
    private HashMap<String, ExecutorService> executors;

    //private WarDao dao;

    private Statistics statistics = new Statistics();

    private WarController(){
        missileLaunchers = new HashMap<>();
        missileDestructors = new HashMap<>();
        launcherDestructors = new HashMap<>();
        executors = new HashMap<>();
        startRunTime = LocalTime.now();
    }

    public static WarControllerFacade getInstance(){
        return warController;
    }

    @Override
    public void addLauncher(Launcher launcher){
        LauncherController launcherController = new LauncherController(launcher);
        ExecutorService es = Executors.newSingleThreadExecutor();
        es.submit(launcherController);

        missileLaunchers.put(launcher, launcherController);
        executors.put(launcher.getId(), es);

        publish(subscriber -> subscriber.launcherWasAdded(launcher));
    }

    @Override
    public void addLauncherDestructor(LauncherDestructor launcherDestructor) {
        launcherDestructors.put(launcherDestructor, new LauncherDestructorController(launcherDestructor));
        publish(subscriber -> subscriber.launcherDestructorWasAdded(launcherDestructor));
    }

    @Override
    public void addMissileDestructor(MissileDestructor missileDestructor) {
        missileDestructors.put(missileDestructor, new MissileDestructorController(missileDestructor));
        publish(subscriber -> subscriber.missileDestructorWasAdded(missileDestructor));
    }

    @Override
    public boolean launchMissile(Launcher launcher, Destination destination, double potentialDamage) throws InterruptedException, ExecutionException {
        final int MAX_TIME = 11;
        boolean hit = false;

        int maxFlightTime = new Random().nextInt(MAX_TIME) + 4;
        return launchMissile(launcher, destination, potentialDamage, maxFlightTime);
    }

    @Override
    public boolean launchMissile(Launcher launcher, Destination destination, double potentialDamage, long maxFlightTime) throws InterruptedException, ExecutionException{
        boolean hit = false;
        LauncherController launcherController = missileLaunchers.get(launcher);
        Missile missile = new Missile(potentialDamage, destination, maxFlightTime, getTime());

        publish(subscriber -> subscriber.missileLaunched(launcher, missile, destination));

        statistics.increaseNumOfLaunchedMissiles();

        try {
            hit = Executors.newSingleThreadExecutor().submit(() -> launching(launcherController, missile, maxFlightTime)).get();
            if(hit){
                publish(subscriber -> subscriber.missileHit(launcher, missile, destination));
            }
            //hit = launcherController.launch(missile, maxFlightTime);
        }catch (Exception e){
            e.printStackTrace();
        }

        return hit;
    }

    private boolean launching(LauncherController launcherController, Missile missile, long maxFlightTime){
        try {
            boolean hit = launcherController.launch(missile, maxFlightTime);

            if(hit) {
                statistics.increaseNumOfHits();
                statistics.raiseDamage(missile.getDamage());
            }
            return hit;
        } catch (InterruptedException |ExecutionException e1) {
            e1.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean destructMissile(MissileDestructor missileDestructor, Missile missile) {
        boolean destruct = false;
        long timeFromLaunch;
        MissileDestructorController missileDestructorController = missileDestructors.get(missileDestructor);
        for(LauncherController launcherController: missileLaunchers.values()){
            if(launcherController.isCurrentlyLaunching()){
                MissileController missileController = launcherController.getActiveMissileController();
                if(missileController == null){
                    System.out.println("missile is not destructed!!");
                }
                if(missileController.getMissile().equals(missile)){
                    publish(subscriber -> subscriber.missileDestructed(missileDestructor, missile));
                    sleepRandomTime();
                    timeFromLaunch = getTime() - missileController.getMissile().getLaunchTime();

                    Future<Boolean> destructionFuture= Executors.newSingleThreadExecutor().submit(() ->
                    destructingMissile(missileDestructorController, missileController, timeFromLaunch, missile));
                    try {
                        destruct = destructionFuture.get();
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                    }
                    return destruct;
                }
            }
        }
        return destruct;
    }

    private boolean destructingMissile(MissileDestructorController missileDestructorController,
                                       MissileController missileController, long timeFromLaunch, Missile missile){
        boolean destruct =missileDestructorController.destruct(missileController, timeFromLaunch); //assumption: always FALSE!
        System.out.println(missile.getId()+": destructed? " + destruct);
        if(destruct) {
            statistics.increaseNumOfDestructedMissiles();
        }
        return destruct;
    }

    @Override
    public boolean destructLauncher(LauncherDestructor launcherDestructor, Launcher launcher) throws InterruptedException {
        final int MAX_TIME = 7;
        boolean succeed = false;

        int destructionTime = new Random().nextInt(MAX_TIME) + 4;
        LauncherController launcherController = missileLaunchers.get(launcher);
        LauncherDestructorController launcherDestructorController =
                launcherDestructors.get(launcherDestructor);

        publish(subscriber -> subscriber.tryToDestructLauncher(launcherDestructor, launcher, MAX_TIME));
        Thread.sleep(destructionTime * 1000);

        succeed = launcherDestructorController.destruct(launcherController, getTime());

        if(succeed){
            publish(subscriber -> subscriber.launcherDestructed(launcherDestructor, launcher));
            statistics.increaseNumOfDestructedLaunchers();
        }


        return succeed;
    }

    @Override
    public Statistics getStatistics() {
        return statistics;
    }

    @Override
    public void exit() {
        for(ExecutorService es : executors.values()){
            es.shutdown();
        }
        System.out.println("The War is Over! PEACE");
    }

    @Override
    public Set<Launcher> retrieveLaunchers() {
        return missileLaunchers.keySet();
    }

    @Override
    public Set<MissileDestructor> retrieveMissileDestructors() {
        return missileDestructors.keySet();
    }

    @Override
    public Set<LauncherDestructor> retrieveLauncherDestructors() {
        return launcherDestructors.keySet();
    }

    @Override
    public Set<Missile> retrieveActiveMissiles() {
        Set<Missile> activeMissiles = new HashSet<>();
        for(LauncherController launcherController : missileLaunchers.values()){
            if(launcherController.isCurrentlyLaunching()) {
                activeMissiles.add(launcherController.getActiveMissileController().getMissile());
            }
        }

        return activeMissiles;
    }

    public static long getTime(){
        return SECONDS.between(startRunTime,LocalTime.now());
    }

    private void sleepRandomTime(){
        try {
            Thread.sleep(Double.valueOf(Math.random()).longValue()*10 + 1);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
