package War.DAL;

public class JsonWarReader {

}
