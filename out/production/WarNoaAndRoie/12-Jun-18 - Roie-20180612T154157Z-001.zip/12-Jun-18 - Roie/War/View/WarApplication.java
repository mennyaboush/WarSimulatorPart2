package War.View;

import War.BusinessLogic.WarController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;

public class WarApplication extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {

       // FXMLLoader loader = new FXMLLoader(getClass().getResource("/War/View/WarMainWindowFreePane.fxml"));
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/War/View/WarMainWindow.fxml"));
        Scene mainScene = new Scene(loader.load());

        primaryStage.setScene(mainScene);
        primaryStage.setFullScreen(true);
        primaryStage.setResizable(false);

        primaryStage.setOnCloseRequest(v -> {
            WarController.getInstance().exit();
            System.exit(0);}
        );
        primaryStage.show();
    }
}
