package War.View;

import War.BusinessLogic.WarController;
import War.BusinessLogic.WarControllerFacade;

public class War {
    static int timeInSec;
    static WarControllerFacade warControllerFacade = WarController.getInstance();

    public static void main(String[] args) {
        AbstractWarView abstractWarView = new ConsoleView(warControllerFacade);
        abstractWarView.start();
        WarApplication.main(args);
    }
}
