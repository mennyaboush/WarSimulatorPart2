package War.View.EntitiesViews;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.ObjectProperty;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;

public class WeaponView<W> extends ImageView implements Toggle{
    private W weapon = null;
    private boolean isSelected = false;
    private boolean selectable = false;
    private ToggleGroup toggleGroup;
    protected WeaponView(W weapon, String imageURL){
        super(imageURL);
        getStyleClass().add("weapon");
        setWeapon(weapon);
        setSelectable(true);
    }

    protected WeaponView(String imageURL){
        super(imageURL);
        getStyleClass().add("weapon");
        setSelectable(true);
    }

    public W getWeapon() {
        return weapon;
    }

    private void setWeapon(W weapon) {
        this.weapon = weapon;
    }

    @Override
    public ToggleGroup getToggleGroup() {
        return toggleGroup;
    }

    @Override
    public void setToggleGroup(ToggleGroup toggleGroup) {
        if(toggleGroup.getToggles().contains(this))
            return;

        toggleGroup.getToggles().add(this);
        this.toggleGroup = toggleGroup;
    }

    @Override
    public ObjectProperty<ToggleGroup> toggleGroupProperty() {
        return null;
    }

    @Override
    public boolean isSelected() {
        return isSelected;
    }

    @Override
    public void setSelected(boolean selected) {
        isSelected = selected;
        if(!selected)
            setStyle("-fx-effect: dropshadow(three-pass-box, rgb(6,6,6), 10, 0, 0, 0);\n");
        if(isSelected)
            toggleGroup.selectToggle(this);
    }

    @Override
    public BooleanProperty selectedProperty() {
        return null;
    }

    public boolean isSelectable() {
        return selectable;
    }

    public void setSelectable(boolean selectable) {
        this.selectable = selectable;
        if(selectable){
            activateSelection();
        }else{
            disableSelection();
            setStyle("-fx-effect: dropshadow(three-pass-box, rgb(251,253,255), 10, 0, 0, 0);\n");
            isSelected = false;
        }
    }

    private void activateSelection(){
        setOnMouseEntered(e -> {
            if(!isSelected)
                setStyle("-fx-effect: dropshadow(three-pass-box, rgb(251,253,255), 10, 0, 0, 0);\n");
        });


        setOnMouseClicked(e -> {
            if (!isSelected) {
                setStyle("-fx-effect: dropshadow(three-pass-box, rgb(0,255,144), 15, 0, 0, 0);\n");
                isSelected = true;
           /*     synchronized (session){
                    session.notify();
                }*/
            } else {
                setStyle("-fx-effect: dropshadow(three-pass-box, rgb(251,253,255), 10, 0, 0, 0);\n");
                isSelected = false;
            }
        });
        setOnMouseExited(e -> {
            if(!isSelected)
                setStyle("-fx-effect: dropshadow(three-pass-box, rgb(6,6,6), 10, 0, 0, 0);\n");
        });
    }

    private void disableSelection(){
        setOnMouseEntered(e -> { });
        setOnMouseClicked(e -> { });
        setOnMouseExited(e -> { });
    }



}
