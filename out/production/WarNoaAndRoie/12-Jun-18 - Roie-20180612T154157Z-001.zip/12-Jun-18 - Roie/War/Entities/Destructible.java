package War.Entities;

public abstract class Destructible extends Weapon {
    private boolean isDestructed = false;

    public Destructible(String id) {
        super(id);
    }

    public boolean isDestructed() {
        return isDestructed;
    }

    public void destruct() {
        isDestructed = true;
    }

    @Override
    public String toString() {
        return String.format("%s Destructed: %4s",super.toString(), isDestructed());
    }
}
