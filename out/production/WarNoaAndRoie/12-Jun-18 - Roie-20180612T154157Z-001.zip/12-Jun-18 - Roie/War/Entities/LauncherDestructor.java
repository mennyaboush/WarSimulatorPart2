package War.Entities;

public class LauncherDestructor extends Destructor<Launcher> {
    public enum DestructorType {PLANE, SHIP}

    private DestructorType type;

    public LauncherDestructor(DestructorType type) {
        setType(type);
    }

    public DestructorType getType() {
        return type;
    }

    public void setType(DestructorType type) {
        this.type = type;
    }
    @Override
    public String toString() {
        return String.format("%s [%6s]",super.toString(),getType().toString());
    }
}
