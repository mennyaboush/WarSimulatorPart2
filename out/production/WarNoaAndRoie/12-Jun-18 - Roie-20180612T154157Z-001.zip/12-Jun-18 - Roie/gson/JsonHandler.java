package gson;

import War.BusinessLogic.WarController;
import War.BusinessLogic.WarControllerFacade;
import War.Entities.Destination;
import gson.Adapters.GsonAdapters;
import gson.entities.DestructedLauncher;
import gson.entities.DestructedMissile;

import java.lang.reflect.Method;
import java.time.LocalTime;
import java.util.List;
import java.util.TreeMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class JsonHandler implements Runnable{
    private WarControllerFacade controller = WarController.getInstance();
    private GsonAdapters adapter = new GsonAdapters();
    private TreeMap<LocalTime, Method> timeLine;
    private ScheduledExecutorService scheduledPool;

    private gson.entities.War gWar;

    public JsonHandler(gson.entities.War gWar){
        setgWar(gWar);
        scheduledPool = Executors.newScheduledThreadPool(8);
    }

    public void setgWar(gson.entities.War gWar) {
        this.gWar = gWar;
    }

    @Override
    public void run() {
        System.out.println("Load Begin!!");
        addLaunchers(gWar.getMissileLaunchers().getLauncher());
        System.out.println("1");
        addMissileDestructors(gWar.getMissileDestructors().getDestructor());
        System.out.println("2");
        addLauncherDestructors(gWar.getMissileLauncherDestructors().getDestructor());
        System.out.println("3");
        launchMissile(gWar.getMissileLaunchers().getLauncher());
        System.out.println("4");
        destructMissile(gWar.getMissileDestructors().getDestructor());
        System.out.println("5");
        destructLauncher(gWar.getMissileLauncherDestructors().getDestructor());
        System.out.println("Load Complete!!");
    }

    private void addLaunchers(List<gson.entities.Launcher> jLaunchers){
        for (gson.entities.Launcher launcher : jLaunchers){
            controller.addLauncher(adapter.adaptLauncher(launcher));
        }
    }

    private void addMissileDestructors(List<gson.entities.Destructor> jMissileDestructors){
        for (gson.entities.Destructor missileDestructor : jMissileDestructors){
            controller.addMissileDestructor(
                    adapter.adaptMissileDestructor(missileDestructor));
        }
    }

    private void addLauncherDestructors(List<gson.entities.Destructor_> jLauncherDestructors){
        for (gson.entities.Destructor_ launcherDestructor : jLauncherDestructors){
            controller.addLauncherDestructor(
                    adapter.adaptLauncherDestructor(launcherDestructor));
        }
    }

    private void setTimeLine(){
        launchMissile(gWar.getMissileLaunchers().getLauncher());
        destructMissile(gWar.getMissileDestructors().getDestructor());
        destructLauncher(gWar.getMissileLauncherDestructors().getDestructor());
    }

    private void launchMissile(List<gson.entities.Launcher> jlaunchers){
        for(gson.entities.Launcher launcher : jlaunchers){
            for(gson.entities.Missile missile : launcher.getMissile()){
                long time = missile.getLaunchTime();
                War.Entities.Launcher launcherParam = adapter.adaptLauncher(launcher);
                Destination destinationParam = new Destination(missile.getDestination());
                double potentialDamageParam = missile.getDamage();
                long maxFlightTimeParam = missile.getFlyTime();
                scheduledPool.schedule(() -> controller.launchMissile(
                        launcherParam,
                        destinationParam,
                        potentialDamageParam,
                        maxFlightTimeParam),
                        time,TimeUnit.SECONDS);
            }
        }
    }

    private void destructMissile(List<gson.entities.Destructor> jMissileDestructors){
        for(gson.entities.Destructor missileDestructor : jMissileDestructors){
            for(DestructedMissile gMissile : missileDestructor.getDestructedMissile()){
                for (War.Entities.Missile warMissile : controller.retrieveActiveMissiles()){
                    if(gMissile.getId().equals(warMissile.getId())){
                        long time = warMissile.getLaunchTime() + gMissile.getDestructAfterLaunch();
                        scheduledPool.schedule(() -> controller.destructMissile(
                                adapter.adaptMissileDestructor(missileDestructor),
                                warMissile),
                                time,TimeUnit.SECONDS);
                        break;
                    }
                }
            }
        }
    }

    private void destructLauncher(List<gson.entities.Destructor_> jlauncherDestructors){
        for(gson.entities.Destructor_ launcherDestructor : jlauncherDestructors) {
            for(DestructedLauncher gLauncher : launcherDestructor.getDestructedLauncher()) {
                for (War.Entities.Launcher warLauncher : controller.retrieveLaunchers()){
                    if(gLauncher.getId().equals(warLauncher.getId())){
                        if(gLauncher.getId().equals(warLauncher.getId())){
                            long time = gLauncher.getDestructTime();
                            scheduledPool.schedule(() -> controller.destructLauncher(
                                    adapter.adaptLauncherDestructor(launcherDestructor),
                                    warLauncher),
                                    time,TimeUnit.SECONDS);
                            break;
                        }
                    }
                }
            }
        }
    }
}
