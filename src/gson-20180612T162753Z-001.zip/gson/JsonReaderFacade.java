package gson;

import gson.entities.War;

public interface JsonReaderFacade {
    War readJson();
}
